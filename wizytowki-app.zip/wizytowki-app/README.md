# Wizytówki – aplikacja Android

Prywatna aplikacja do skanowania dwustronnych wizytówek (PL/EN) i budowania lokalnej bazy kontaktów.

- Wymagania: `REQUIREMENTS.md`
- Plan etapów: `docs/ROADMAP.md`
- Zasady dla agenta AI: `AGENTS.md`

## Jak pracujemy
1. Zadania są w GitHub Issues (tworzy je `scripts/create_issues.sh`).
2. Agent AI (Claude Code / Codex) bierze jedno zadanie, pracuje na osobnej gałęzi i otwiera pull request.
3. GitHub Actions buduje aplikację, uruchamia testy i lint, a do PR dołącza plik APK.
4. Właściciel przegląda PR, instaluje APK na telefonie i zatwierdza albo prosi o poprawki.
